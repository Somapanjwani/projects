/**
 * 
 */
/**
 * 
 */
module Snake {
}